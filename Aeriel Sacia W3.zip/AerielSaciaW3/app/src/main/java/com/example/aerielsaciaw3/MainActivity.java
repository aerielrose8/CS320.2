package com.example.aerielsaciaw3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
    @Override
    public void onClick(View v) {

        // get a reference to the TextView on the UI
        TextView textMessage = (TextView) findViewById(R.id.textMessage);

        //get a reference to the EditText so that we can read in the value typed
        // by the user
        EditText editFriendName = (EditText) findViewById(R.id.editFriendName);

        // get the name of the friend typed in by the user in the EditText field
        String friendName = editFriendName.getText().toString();

        //Get the time of day
        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int hour = cal.get(Calendar.HOUR_OF_DAY);

        //Set greeting
        String greeting = null;
        if(hour>=6 && hour<12){
            greeting = "Good Morning";
        } else if(hour>= 12 && hour < 17){
            greeting = "Good Afternoon";
        } else if(hour >= 17 && hour < 21){
            greeting = "Good Evening";
        } else if(hour >= 21 && hour < 24){
            greeting = "Good Night";
        }

        //Change string displayed by TextView
        switch (v.getId()) {

            case R.id.greetButton:

                //set the string being displayed by the TextView to the greeting
                //message for the friend
                textMessage.setText( greeting + " " + friendName + "!");

                break;

            default:
                break;
        }

    }
    <?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
            xmlns:tools="http://schemas.android.com/tools"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:orientation="vertical"
            tools:context=".MainActivity"
            tools:ignore="HardcodedText">

<EditText
        android:id="@+id/firstName"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginStart="16dp"
                android:layout_marginTop="16dp"
                android:layout_marginEnd="16dp"
                android:hint="First Name"
                android:inputType="text" />

<EditText
        android:id="@+id/lastName"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginStart="16dp"
                android:layout_marginTop="16dp"
                android:layout_marginEnd="16dp"
                android:hint="Last Name"
                android:inputType="text" />

<EditText
        android:id="@+id/email"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginStart="16dp"
                android:layout_marginTop="16dp"
                android:layout_marginEnd="16dp"
                android:hint="Email"
                android:inputType="textEmailAddress" />

<EditText
        android:id="@+id/password"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginStart="16dp"
                android:layout_marginTop="16dp"
                android:layout_marginEnd="16dp"
                android:hint="Password"
                android:inputType="textPassword" />

<LinearLayout
        android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="8dp"
                android:gravity="end"
                android:orientation="horizontal">

<Button
            android:id="@+id/cancelButton"
                    style="@style/Widget.AppCompat.Button.Borderless"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginEnd="4dp"
                    android:text="CANCEL"
                    android:textColor="@color/colorPrimary" />

<Button
            android:id="@+id/proceedButton"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginEnd="16dp"
                    android:backgroundTint="@color/colorPrimary"
                    android:text="PROCEED"
                    android:textColor="@android:color/white"
                    tools:ignore="ButtonStyle" />

</LinearLayout>
</LinearLayout>
<Button
        android:id="@+id/button"
                android:layout_height="wrap_content"
                android:layout_width="wrap_content"
                android:text="@string/button_text"
                android:clickable = "false" />